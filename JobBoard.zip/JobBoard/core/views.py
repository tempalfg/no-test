from django.core.paginator import Paginator

from django.contrib import auth
from django.contrib.auth import login
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django.shortcuts import render, redirect
from django.contrib import messages

from job.models import Job
from userprofile.models import Userprofile
from .forms import RegistrationForm, UserLoginForm


def frontpage(request, search_query=None, count=None):

    if search_query is None:
        jobs = Job.objects.all().filter(status=Job.ACTIVE)
    else:
        if search_query == ' ':
            search_query = ''
        if count == ' ':
            count = ''

        jobs = Job.objects.filter(Q(title__iregex=search_query) & Q(company_size__iregex=count) & Q(status=Job.ACTIVE))

    paginator = Paginator(jobs, 8)

    page_number = request.GET.get("page")
    jobs = paginator.get_page(page_number)

    context = {'jobs': jobs, }

    return render(request, 'core/frontpage.html', context)


def signup(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)

        if form.is_valid():
            user = form.save()

            account_type = request.POST.get('account_type', 'jobseeker')
            if account_type == 'employer':
                userprofile = Userprofile(user=user, is_employer=True)
                userprofile.save()
            else:
                userprofile = Userprofile(user=user, is_employer=False)
                userprofile.save()

            login(request, user)

            return redirect('dashboard')
    else:
        form = RegistrationForm()
    context = {'form': form, }
    return render(request, 'core/signup.html', context=context)


def login_user(request):
    if request.method == 'POST':
        form = UserLoginForm(data=request.POST)

        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            try:
                user = User.objects.get(username=username)
            except ObjectDoesNotExist:
                messages.error(request, 'Пользователя с таким логином не существует')

            else:
                user = auth.authenticate(username=username, password=password)
                if user is not None:
                    auth.login(request, user)
                    return redirect('frontpage')
                else:
                    messages.error(request, 'Неверное имя пользователя или пароль')

        else:
            messages.error(request, 'Ошибка авторизации')

    else:
        form = UserLoginForm()

    context = {'form': form, }

    return render(request, 'core/login.html', context=context)


def logout(request):
    auth.logout(request)

    return redirect('login_user')