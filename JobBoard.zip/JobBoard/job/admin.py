from django.contrib import admin
from django.db import models
from .models import Job, Application

from ckeditor.widgets import CKEditorWidget


# class JobAdmin(admin.ModelAdmin):
#     list_display = ('title', 'short_description', 'created_by', 'created_at')
#     list_display_links = ('title',)

class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'short_description', 'created_by', 'created_at')
    list_display_links = ('title',)

    formfield_overrides = {
        models.TextField: {'widget': CKEditorWidget},
    }


class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('job', 'created_by', 'created_at')
    list_display_links = ('job',)


admin.site.register(Job, JobAdmin)
admin.site.register(Application, ApplicationAdmin)