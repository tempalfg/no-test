from django import forms

from .models import Job, Application

from ckeditor.widgets import CKEditorWidget


class AddJobForm(forms.ModelForm):
    title = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите заголовок'
    }))

    short_description = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'input-add_job', 'placeholder': 'Введите короткое описание',
        'rows': 5, 'cols': 30
    }))
    long_description = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'input-add_job', 'placeholder': 'Введите подробное описание',
        'rows': 10, 'cols': 30
    }))

    company_name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите название компании'
    }))

    company_address = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите адрес компании'
    }))

    company_zipcode = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите почтовый индекс компании'
    }))

    company_place = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите город компании'
    }))

    company_country = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите страну компании'
    }))

    company_size = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'input', 'placeholder': 'Введите заголовок'
    }))

    class Meta:
        model = Job
        fields = ['title', 'short_description', 'long_description', 'company_name',
                  'company_address', 'company_zipcode', 'company_place', 'company_country', 'company_size']


class ApplicationForm(forms.ModelForm):
    content = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'input-add_job', 'placeholder': 'Расскажи о себе',
        'rows': 10, 'cols': 70
    }))
    experience = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'input-add_job', 'placeholder': 'Расскажи о своем опыте',
        'rows': 10, 'cols': 70
    }))

    class Meta:
        model = Application
        fields = ['content', 'experience']




